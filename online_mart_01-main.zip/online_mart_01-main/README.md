
```bash
sudo chmod -R 777  /Users/user-name/Documents/folder-name
```

**poetry commands**

python-jose python library to generate access_tokens
```bash
poetry add "python-jose[cryptography]"
``` 

**docker commands**

run docker
```bash
docker compose up
``` 
validate compose file

```bash
docker compose config
``` 

Clear Docker Cache:
docker system prune -a

generate a random string of bytes in hexadecimal format
```bash
openssl rand -hex 32
``` 



Docker Compose with Database Service
https://github.com/panaverse/learn-generative-ai/tree/main/05_microservices_all_in_one_platform/14_docker/05_compose_db

Kafka messaging
https://github.com/panaverse/learn-generative-ai/blob/main/05_microservices_all_in_one_platform/15_event_driven/02_kafka_messaging/compose.yaml

Protobuf Kafka Messaging
https://github.com/panaverse/learn-generative-ai/tree/main/05_microservices_all_in_one_platform/15_event_driven/03_protobuf

[Form Data](https://fastapi.tiangolo.com/tutorial/request-forms/)
[FormData vs. JSON: Comparison](https://chatgpt.com/share/dc922c6e-10cd-4423-9c7a-621755d42787)

oauth2_auth
https://github.com/panaverse/learn-generative-ai/tree/main/05_microservices_all_in_one_platform/16_oauth2_auth


Tokens
https://github.com/panaverse/learn-generative-ai/tree/main/05_microservices_all_in_one_platform/16_oauth2_auth/00_generate_access_token

# online_mart_01
