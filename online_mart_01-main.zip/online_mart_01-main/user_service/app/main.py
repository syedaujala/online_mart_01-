from fastapi import FastAPI, Depends, HTTPException
from typing import Annotated
from sqlmodel import Session, select

from app.db.db_connector import  get_session, create_db_and_tables, DB_SESSION
from app.models.user_model import User, UserModel 


app = FastAPI(lifespan = create_db_and_tables)

@app.get('/')
def get_route():
    return "user service"


@app.get("/api_user1/", response_model=list[User])
def get_user(session: Annotated[Session, Depends(get_session)]):
        users = session.exec(select(User)).all()
        if not users:
              raise HTTPException(status_code=404, detail="Users Not Found")
        return users


@app.post("/api_user1/", response_model=User)
def create_user(user_base: UserModel, session: Annotated[Session, Depends(get_session)]):
        #user: User = User.model_validate(user_base)

        # Convert UserModel to User instance
        user: User = User(**user_base.dict())
        # Add the user to the session
        session.add(user)
        # Commit the session to save the user to the database
        session.commit()
        # Refresh the session to retrieve the new user data, including generated fields like user_id
        session.refresh(user)
        print("user ...",user)
        # Return the created user
        return user


@app.put('/api/update_user1', response_model=User)
def update_user(selected_id: int, user_base: UserModel, session: Annotated[Session, Depends(get_session)]):
    # Construct a query to select the user with the specified user_id
    user_query = select(User).where(User.user_id == selected_id)
    
    # Execute the query and get the first result
    user_statment = session.exec(user_query).first()
    
    # If no user is found with the given ID, raise a 404 HTTPException
    if not user_statment:
        raise HTTPException(status_code=404, detail="User is unavailable")
    
    # Update the fields of the user with the values from the user_base object
    user_statment.user_name = user_base.user_name
    user_statment.user_email = user_base.user_email
    user_statment.user_password = user_base.user_password
    user_statment.address = user_base.address
    user_statment.country = user_base.country
    user_statment.phone_number = user_base.phone_number

    
    # Add the updated user instance to the session
    session.add(user_statment)
    
    # Commit the transaction to save changes to the database
    session.commit()
    
    # Refresh the session to get the updated user instance
    session.refresh(user_statment)
    
    # Return the updated user instance
    return user_statment

